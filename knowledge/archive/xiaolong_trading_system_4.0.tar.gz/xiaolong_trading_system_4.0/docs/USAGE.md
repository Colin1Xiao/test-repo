# 小龙交易系统 4.0 使用文档

## 安装依赖
```bash
pip install -r requirements.txt
```

## 配置系统
1. 复制配置模板到工作目录
   ```bash
   cp config/trader_config.json ~/.openclaw/workspace/
   cp config/symbols_config.json ~/.openclaw/workspace/
   cp config/telegram_config.json ~/.openclaw/workspace/
   ```

2. 配置 OKX API 密钥
   ```bash
   mkdir -p ~/.openclaw/secrets
   # 编辑 ~/.openclaw/secrets/okx_api.json
   ```

## 启动系统
```bash
cd xiaolong_trading_system_4.0
python3 xiaolong_trading_system.py
```

或使用脚本：
```bash
./scripts/start_monitor.sh
```

## 监控系统
- **实时日志**: `tail -f logs/monitor_live.log`
- **RL 数据**: `ls -la data/rl_data/`
- **状态机日志**: `tail -f logs/execution_state_machine.log`

## 紧急操作
- **停止系统**: `Ctrl+C` 或 `pkill -f xiaolong_trading_system`
- **回滚 V2**: `./scripts/stop_v3_start_v2.sh`

## 风险控制
- **小仓位测试**: 建议初始本金 3-5 USD
- **高杠杆风险**: 100x 杠杆需谨慎
- **监控告警**: 确保 Telegram 告警正常
- **紧急回滚**: 准备好 V2 回滚方案
