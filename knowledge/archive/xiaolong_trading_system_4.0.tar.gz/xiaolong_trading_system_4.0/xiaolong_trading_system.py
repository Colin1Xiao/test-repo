#!/usr/bin/env python3
"""
小龙交易系统 4.0 - 主入口
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.auto_monitor_v3 import AutoMonitorV3

def main():
    """主函数"""
    print("=" * 70)
    print("🐉 小龙交易系统 4.0")
    print("=" * 70)
    
    try:
        monitor = AutoMonitorV3()
        import asyncio
        asyncio.run(monitor.run())
    except KeyboardInterrupt:
        print("\n⛔ 系统已停止")
    except Exception as e:
        print(f"\n❌ 系统错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
